#ifndef UI_H
#define UI_H

/* Reset */
#define RESET       "\033[0m"

/* Regular Colors */
#define BLACK       "\033[0;30m"
#define RED         "\033[0;31m"
#define GREEN       "\033[0;32m"
#define YELLOW      "\033[0;33m"
#define BLUE        "\033[0;34m"
#define MAGENTA     "\033[0;35m"
#define CYAN        "\033[0;36m"
#define WHITE       "\033[0;37m"
#define ORANGE      "\033[38;5;208m" // Orange color using 256-color mode
#define PURPLE      "\033[38;5;93m"  // Purple color using 256-color mode

#endif
