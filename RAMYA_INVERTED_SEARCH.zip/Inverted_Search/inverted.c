/* 
    NAME         :  RAMYA AMBATI

    TITLE        :  Inverted Search 

    DESCRIPTION  :  * This project purpose is to search for a word in multiple files 
                    and display the files in which the word is present.
                    * The project uses a hash table to store the words from the files 
                    and a linked list to store the file names. 

    FILES        : main function is  inverted.c 
                    file_validation.c - validates the command line arguments and checks for duplicate files
                    SL_list.c - implements the linked list functions
                    database.c - implements the hash table functions
                    inverted.h - header file for linked list functions
                    database.h - header file for hash table functions

    COMPILER     :  gcc compiler - compile as gcc *.c

    INPUT        :  ./a.out <file1.txt> <file2.txt> <file3.txt> ...

    OUTPUT       :  Displays the word , file count, filename and word count in a tabular format
*/
#include "inverted.h"
#include "database.h"
#include "ui.h"
#include <stdio.h>

int main(int argc,char *argv[])
{
    SL *head = NULL;
    if(argc < 2)
    {
        printf(RED"ERROR:Invalid No.of args\n"RESET);
        return -1;
    }
    else
    {
        if(cla_validation(argv,&head) == -1)
        {
            printf(RED"ERROR:Invalid command line arguments\n"RESET);
            return -1;
        }
        int flag = 0;
        do{
        printf(PURPLE"\n👉Select among the following options:👈\n"RESET);
        printf("1.create database 🙂\n2.display database 🖥️\n3.search database 🔍\n4.save 📁\n5.update 📥\n6.exit 🔚\n");
        int choice;
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
                if(flag == 1)
                {
                    printf(YELLOW"Database is already created\n"RESET);
                    break;
                }
                int result = create_database(head);
                if(result == -1)
                {
                    printf(RED"ERROR:Database creation failed\n"RESET);
                    return -1;
                }
                else
                {
                    flag = 1;
                    printf(GREEN"\nDatabase created successfully\n"RESET);
                    break;
                }
            case 2:
                display_database();
                break;
            case 3:
                char word[10];
                printf(ORANGE"👉Enter the word you want to search👈\n"RESET);
                scanf("%s",word);
                search_db(word);
                break;
            case 4:
                printf(ORANGE"👉Enter the filename you want to save in database👈\n"RESET);
                char filename[20];
                scanf("%s",filename);
                save_db(filename);
                break;
            case 5:
                char db_fname[20];
                printf(ORANGE"👉Enter the filename you want to update in database👈\n"RESET);
                scanf("%s",db_fname);

                for(int i = 0; i < 27; i++)
                {
                    arr[i].index = i;
                    arr[i].h_link = NULL;
                }
                if(update_db(db_fname) == 0)
                {
                    delete_database(&head);
                    flag = 0;
                    printf(GREEN"Database updated successfully✅\n"RESET);
                    print_list(head);
                }
                else
                {
                    printf(RED"ERROR:Database update failed😥\n"RESET);
                }
                break;
            case 6:
                return 0;
            default :
                printf(RED"Invalid choice!!😒\n"RESET);
        }
        }while(1);
    }
}