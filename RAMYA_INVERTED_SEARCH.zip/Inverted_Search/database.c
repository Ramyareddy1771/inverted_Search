#include "database.h"
#include "inverted.h"
#include "ui.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

hash_t arr[27]; //global hash table array 
int find_index(char word[])
{
    if(word[0] >= 'a' && word[0] <= 'z')
        {
            return word[0] - 97;
        }
        else if(word[0] >= 'A' && word[0] <= 'Z')
        {
            return word[0] - 65;
        }
        else
        {
            return 26; //for special characters
        }
}
int create_database(SL *head)
{
    SL *temp = head;
    char word[20];
    while(temp != NULL)
    {
        //open file to get each node
        FILE *fp = fopen(temp->filename,"r");
        if(fp == NULL)
        {
            printf(RED"ERROR:Could not open %s for reading\n"RESET,temp->filename);
            return -1;
        }
        //reading filename from file - storing in word
        while (fscanf(fp, "%99s", word) == 1)
        {
            /*finding index for hash table based on first character of word */
            int index;
            index = find_index(word);
            
            if(insert_hash_table(arr,index, word, temp) == -1)
            {
                printf(RED"ERROR:Failed to insert %s in hash table\n"RESET, word);
            }
            else
            {
                //printf("Inserted %s in hash table\n", word);
            }
        }

        fclose(fp); //closing current file
        printf(CYAN"\nINFO:Successfully processed %s into hash table. \n"RESET, temp->filename);
        temp = temp->link; //moving to next file in LL
    }
    return 0;
}
int insert_hash_table(hash_t arr[], int ind, char *word, SL *temp)
{
    arr[ind].index = ind;

    //if table is empty, create mainnode and subnode
    if(arr[ind].h_link == NULL)
    {
        //create main node and allocate memory
        mainnode *main_new = malloc(sizeof(mainnode));
        if(main_new == NULL)
        {
            return -1;
        }

        //create sub node and allocate memory
        subnode *sub_new = malloc(sizeof(subnode));
        if(sub_new == NULL)
        {
            return -1;
        }

        //update hash table
        arr[ind].h_link = main_new;

        //update mainnode
        strcpy(main_new->word, word);
        main_new->sublink = sub_new;
        main_new->link = NULL;
        main_new->file_count = 1;
        

        //update subnode
        strcpy(sub_new->filename, temp->filename);
        sub_new->word_count = 1;
        sub_new->link = NULL;

        return 0;

    }
        //if table is not empty, check if word already exists in mainnode
        mainnode *main_new = arr[ind].h_link;

        while(main_new != NULL)
        {
            //if already exists
            if(strcmp(main_new->word,word) == 0)
            {
                subnode *sub_new = main_new->sublink;

                //check if filename already exists in subnode
                while(sub_new != NULL)
                {
                    //if exists increment word_count and return
                    if(strcmp(sub_new->filename, temp->filename) == 0)
                    {
                        sub_new->word_count++;
                        return 0;
                    }
                    sub_new = sub_new->link;
                }
                //if not exists create new subnode & add to the end of the list
                if(sub_new == NULL)
                {
                    //create new subnode and allocate memory
                    subnode *sub_new = malloc(sizeof(subnode));
                    if(sub_new == NULL)
                    {
                        return -1;
                    }
                    strcpy(sub_new->filename, temp->filename);
                    sub_new->word_count = 1;
                    sub_new->link = NULL;

                    main_new->file_count++;

                    //add new subnode to the end of the list
                    subnode *temp_sub = main_new->sublink;
                    while(temp_sub->link != NULL)
                    {
                        temp_sub = temp_sub->link;
                    }
                    temp_sub->link = sub_new;

                    return 0;
                }

            }
            main_new = main_new->link;
        }
        
            //if word not found create new mainnode and allocate memory
            main_new = malloc(sizeof(mainnode));
            if(main_new == NULL)
            {
                return -1;
            }
            //create new subnode and allocate memory
            subnode *sub_new = malloc(sizeof(subnode));
            if(sub_new == NULL)
            {
                return -1;
            }
            //update mainnode
            strcpy(main_new->word, word);
            main_new->file_count = 1;
            main_new->sublink = sub_new;
            main_new->link = NULL;

            //update subnode
            strcpy(sub_new->filename, temp->filename);
            sub_new->word_count = 1;
            sub_new->link = NULL;

            //add new mainnode to the end of the list
            mainnode *temp_main = arr[ind].h_link;
            while(temp_main->link != NULL)
            {
                temp_main = temp_main->link;
            }
            temp_main->link = main_new;

    return 0;
}
int display_database()
{
    printf("\n=====================================================================================\n");
    printf(BLUE"%-20s %-12s %-20s %-12s\n"RESET,
           "WORD", "FILE COUNT", "FILENAME", "WORD COUNT");
    printf("=====================================================================================\n");

    for(int i = 0; i < 27; i++)
    {
        mainnode *main_new = arr[i].h_link;

        while(main_new != NULL)
        {
            subnode *sub_new = main_new->sublink;

            int first = 1;

            while(sub_new != NULL)
            {
                if(first)
                {
                    printf(MAGENTA"%-20s %-12d %-20s %-12d\n"RESET,
                           main_new->word,
                           main_new->file_count,
                           sub_new->filename,
                           sub_new->word_count);
                    first = 0;
                }
                else
                {
                    printf(CYAN"%-20s %-12s %-20s %-12d\n"RESET,
                           "",
                           "",
                           sub_new->filename,
                           sub_new->word_count);
                }

                sub_new = sub_new->link;
            }

            printf("-------------------------------------------------------------------------------------\n");
            main_new = main_new->link;
        }
    }

    return 0;
}
int search_db(char word[])
{
    int index;
    index = find_index(word);
    printf(YELLOW"Searching for word: %s in index: %d\n"RESET, word, index);
    mainnode *main_new = arr[index].h_link;
    while(main_new != NULL)
    {
        //printf("Stored word: '%s'\n", main_new->word);
        if(strcmp(main_new->word, word) == 0)
        {
            printf(GREEN"Word: %s is present in %d files\n"RESET,word,main_new->file_count);
            subnode *sub_new = main_new->sublink;
            while(sub_new != NULL)
            {
                printf(ORANGE"\tFilename: %s, Word Count: %d\n"RESET, sub_new->filename, sub_new->word_count);
                sub_new = sub_new->link;
            }
            return 0; 
        }
        main_new = main_new->link;
    }
    
            //if word not found
            printf(RED"Word: %s is not present in the database\n"RESET,word);
            return -1;
}
int update_db(char *filename)
{
    // Implementation for updating the database
    FILE *fp = fopen(filename, "r");
    if(fp == NULL)
    {
        printf(RED"ERROR: Could not open %s for reading\n"RESET,filename);
        return -1;
    }

    while(1)
    {
        int index,filecount;
        char word[20];

        //Read one complete database record.
        if(fscanf(fp, "#%d;%[^;];%d;", &index, word, &filecount) != 3)
        {
            break; // End of file or error
        }

        //create new mainnode and allocate memory
        mainnode *main_new = malloc(sizeof(mainnode));
        if(main_new == NULL)
        {
            printf(RED"ERROR: Memory allocation failed for mainnode\n"RESET);
            fclose(fp);
            return -1;
        }

        //store word and file count in the main node
        strcpy(main_new->word, word);
        main_new->file_count = filecount;
        main_new->sublink = NULL; // Reset sublink for new data
        main_new->link = NULL; // Reset link for new data     

        //create subnodes according to filecount and link them to the mainnode
        subnode *last = NULL;

        for(int i = 0;i < filecount;i++)
        {
            subnode *sub_new = malloc(sizeof(subnode));
            if(sub_new == NULL)
            {
                fclose(fp);
                printf(RED"ERROR: Memory allocation failed for subnode\n"RESET);
                return -1;
            }
            fscanf(fp, "%[^;];%d;", sub_new->filename, &sub_new->word_count);
            sub_new->link = NULL;

            if(main_new->sublink == NULL)
            {
                main_new->sublink = sub_new;
            }
            else
            {
                last->link = sub_new;
            }
            last = sub_new;
        }
        fscanf(fp, "#\n"); // Read the end of the mainnode entry

        // Add mainnode to the hash table
        if(arr[index].h_link == NULL)
        {
            arr[index].h_link = main_new;
        }
        else
        {
            mainnode *temp = arr[index].h_link;
            while(temp->link != NULL)
            {
                temp = temp->link;
            }
            temp->link = main_new;
        }
    }
    fclose(fp);

    return 0;
}
void save_db(char filename[])
{
    printf(ORANGE"Saving database to file: %s...\n"RESET, filename);
    //check if file is .txt or not
    if(strstr(filename,".txt") == NULL)
    {
        printf(RED"ERROR: %s is not a .txt file\n"RESET, filename);
        return;
    }
        //open file to write the database
        FILE *fp = fopen(filename, "w");
        if(fp == NULL)
        {
            printf(RED"ERROR: Could not open file %s for writing\n"RESET, filename);
            return;
        }
        //fprintf(fp, "#\n");
        for(int i = 0; i < 27; i++)
        {
            mainnode *main_new = arr[i].h_link;
            while(main_new)
            {
                fprintf(fp,"#%d;%s;%d;",i, main_new->word, main_new->file_count);
                subnode *sub_new = main_new->sublink;
                while(sub_new)
                {
                    fprintf(fp, "%s;%d;", sub_new->filename, sub_new->word_count);
                    sub_new = sub_new->link;
                }
                fprintf(fp, "#\n");
                main_new = main_new->link;
            }
        }
        fclose(fp);
        printf(GREEN"Database saved successfully \n"RESET);
}
void delete_database(SL **head)
{
   for(int i = 0;i < 27;i++)
   {
    mainnode *main_new = arr[i].h_link;
    while(main_new != NULL)
    {
        subnode *sub_new = main_new->sublink;
        while(sub_new != NULL)
        {
            delete_node(head, sub_new->filename);
            sub_new = sub_new->link;
        }
        main_new = main_new->link;
    }
   }
}
