
#ifndef DATABASE_H
#define DATABASE_H

#include "inverted.h"

typedef struct node1
{
    char filename[25];
    int word_count;
    struct node1 *link;
}subnode;

typedef struct node2
{
    int file_count;
    char word[20];
    subnode *sublink; //to point to subnode
    struct node2 *link;
}mainnode;

typedef struct hash
{
    int index;
    mainnode *h_link; //to point to mainnode
    //struct hash arr[27];//26 for a-z and 1 for special characters
}hash_t;
extern hash_t arr[27];

int create_database(SL *head);
int insert_hash_table(hash_t arr[], int ind, char *word, SL *temp);
int display_database();
int search_db(char word[]);
int update_db(char *filename);
void save_db(char filename[]);
void delete_database(SL **head);

#endif