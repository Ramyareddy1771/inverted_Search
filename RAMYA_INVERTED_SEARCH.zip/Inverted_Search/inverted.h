#ifndef INVERTED_H
#define INVERTED_H

#define FAILURE -1;
#define SUCCESS 0;
#define DUP_FOUND 1;
#define DUP_NOT_FOUND 2;

typedef struct node SL;
struct node
{
    struct node *head;
    char filename[25];
    struct node *link;
};

#include "database.h"

int cla_validation(char*[], SL **);
int insert_last_SLL(SL **head,char filename[]);
void print_list(SL *head);
int check_dup(SL *head,char filename[]);
int delete_node(SL **head,char filename[]);
#endif