#include "inverted.h"
#include "database.h"
#include "ui.h"

#include <stdio.h>
#include <string.h>

int cla_validation(char *argv[],SL **head)
{
    //SL *head = NULL;
    int i = 1;
    do
    { 
        char *ptr = strstr(argv[i],".txt");
        if( ptr == NULL || strcmp(ptr,".txt"))
        {
            printf(RED"ERROR:%s is not .txt file\n"RESET,argv[i]);
        }
        else
        {
            //printf("%s is a .txt file\n",argv[i]);

            FILE *fp = fopen(argv[i],"r");
            if(fp == NULL)
            {
                printf(RED"ERROR:%s is not present\n"RESET,argv[i]);
            }
            else
            {
                //printf("%s is present\n",argv[i]);
                fseek(fp,0,SEEK_END);
                long int size = ftell(fp);
                if(size == '\0')
                {
                    printf(RED"ERROR:%s is empty\n"RESET,argv[i]);
                }
                else
                {
                   // printf("%s is not empty\n",argv[i]);

                    /* check if file is duplicate or not */
                    if(check_dup(*head,argv[i]) == 1)
                    {
                        printf(RED"ERROR:%s is already exists\n"RESET,argv[i]);
                    }
                    else
                    {
                        //printf("%s is unique\n",argv[i]);
                        insert_last_SLL(head,argv[i]);
                        printf(MAGENTA"\nINFO:Successful:Inserted %s in linked list\n\n"RESET,argv[i]);
                        
                    }
                }
            }
        }
        i++;
        
    }while(argv[i] != NULL); 
    printf(GREEN"INFO:All files are inserted in linked list\n"RESET);
    print_list(*head);
}