#include "inverted.h"
#include "database.h"
#include "ui.h"

#include<stdio.h>
#include <string.h>
#include <stdlib.h>

int insert_last_SLL(SL **head,char filename[])
{
    /* memory allocation for newnode */
   SL *newnode = malloc(sizeof(SL));
   /* check if memory allocated or not */
   if(newnode == NULL)
   {
     printf(RED"ERROR: Memory allocation failed for newnode\n"RESET);
     return -1; //if not allocated return failure
   }
   /* assign filename to the newnode */
   strcpy(newnode->filename,filename);
   newnode->link = NULL;

   /* if list is empty-update head*/
    if(*head == NULL)
    {
        *head = newnode;
        return 0;
    }
    else
    {
        /* traverse until last node using temp */
        SL *temp = *head;
        while(temp->link != NULL)
        {
            temp = temp->link;
        }
        temp->link = newnode; //insert new filename at end
        return 0;
    }
}
void print_list(SL *head)
{
    if (head == NULL)
    {
        printf(RED"INFO : List is empty\n"RESET);
        return;
    }

    //printf("Files in the list:\n");

    while (head != NULL)
    {
        printf(YELLOW"%s "RESET, head->filename);
        printf(CYAN"-> "RESET);
        head = head->link;
    }

    printf(YELLOW"NULL\n"RESET);
}
int check_dup(SL *head,char filename[])
{
    while (head != NULL)
    {
        if (strcmp(head->filename, filename) == 0)
        {
            return 1;   // Duplicate found
        }
        head = head->link;
    }

    return 2;   // Not found
}

//funtion for deleting node
int delete_node(SL **head,char filename[])
{
    if(*head == NULL)
    {
        printf(RED"INFO : List is empty\n"RESET);
        return -1; //list is empty
    }
    SL *temp = *head;
    SL *prev = NULL;

    while(temp != NULL)
    {
        if(strcmp(temp->filename, filename) == 0)
        {
            if(prev == NULL)
            {
                *head = temp->link; //update head if first node is to be deleted
            }
            else
            {
                prev->link = temp->link; //update link of previous node
            }
            free(temp); //free memory of deleted node
            return 0; //node deleted successfully
        }
        prev = temp;
        temp = temp->link;
    }
    return -1; //node not found
}